% Given System Parameters
k = 1.5;  % Gain value (chosen to satisfy Kv condition)
K_C = 1;  % Lead compensator gain
zero = 3; % Zero of the lead compensator
pole = 20; % Pole of the lead compensator

% Define the Plant Transfer Function
num_plant = 2500 * k;
den_plant = [1, 25, 0]; % s(s+25)
G = tf(num_plant, den_plant);

% Define the Lead Compensator
num_comp = [1, zero];   % (s + zero)
den_comp = [1, pole];   % (s + pole)
G_C = K_C * tf(num_comp, den_comp);

% Open-Loop Transfer Function
G_OL = G_C * G;

% Plot the Bode Diagram for Open-Loop System
figure;
bode(G_OL);
grid on;
title('Bode Diagram for Open-Loop Transfer Function');

% Check the Phase Margin
[GM, PM, Wcg, Wcp] = margin(G_OL);
fprintf('Phase Margin: %.2f degrees\n', PM);
fprintf('Gain Crossover Frequency: %.2f rad/s\n', Wcp);

% Closed-Loop Transfer Function
G_CL = feedback(G_OL, 1);

% Step Response for Settling Time and Overshoot
figure;
step(G_CL);
grid on;
title('Step Response for Closed-Loop System');
info = stepinfo(G_CL);
fprintf('Settling Time: %.2f seconds\n', info.SettlingTime);
fprintf('Overshoot: %.2f%%\n', info.Overshoot);

% Steady-State Error for a Slope Input
slope_input = tf(1, [1, 0, 0]); % 1/s^2
steady_state_error = 1 / dcgain(slope_input * G_OL);
fprintf('Steady-State Error to Slope Input: %.4f%%\n', steady_state_error * 100);
