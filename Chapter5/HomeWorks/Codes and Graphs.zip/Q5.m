% Clear workspace and command window  
clear; clc; close all;  

% Define system parameters  
N = 20;  
K = 10 * N;  % System gain  
num = K;  % Numerator of the system G(s)  
den = [1, 11, 10, 0];  % Coefficients of the denominator (s^3 + 11s^2 + 10s)  
G = tf(num, den);  % Create transfer function  

% Display poles for open-loop system  
fprintf('Poles of Open Loop System:\n');  
disp(pole(G));  

% Initialize parameters for optimization  
best_kD = 0;  
max_phase_margin = -Inf;  
k_D_values = 0:0.01:0.2;  % Reduced range for parameter k_D to prevent instability  
k_P = 0.1;  % Start with a small initial guess for k_P  

% Loop to find optimal k_D that maximizes phase margin  
for k_D = k_D_values  
    T = closed_loop_transfer_function(G, k_P, k_D);  % Calculate T(s)  
    [Gm, Pm, Wcg, Wcp] = margin(T);  % Get gain margin (Gm), phase margin (Pm), and frequencies  
    if ~isfinite(Pm) || Pm <= 0  
        continue;  % Skip unstable configurations  
    end  
    if Pm > max_phase_margin  
        max_phase_margin = Pm;  % Update max phase margin  
        best_kD = k_D;  % Record the best k_D found  
        gain_margin = Gm;  % Record the gain margin  
        bandwidth = Wcg;  % Record the bandwidth  
    end  
end  

% Display optimal results  
fprintf('Optimal k_D: %f\n', best_kD);  
fprintf('Maximum Phase Margin: %f degrees\n', max_phase_margin);  
fprintf('Gain Margin: %f\n', gain_margin);  
fprintf('Bandwidth: %f rad/s\n', bandwidth);  

% Create final closed-loop transfer function with optimal k_D  
T_final = closed_loop_transfer_function(G, k_P, best_kD);  

% Bode plot of the closed-loop system  
figure;  
bode(T_final);  
grid on;  
title('Bode Plot of the Closed-Loop System');  

% Step response of the closed-loop system  
figure;  
step(T_final);  
grid on;  
title('Step Response of the Closed-Loop System');  

% Simulate a ramp response for verification  
time = 0:0.1:20;  % Time vector  
ramp_input = time;  % Ramp input  
ramp_figure = lsim(T_final, ramp_input, time);  % Simulate the response to a ramp  
figure;  
plot(time, ramp_figure);  
grid on;  
title('Response of the System to a Ramp Input');  
xlabel('Time (s)');  
ylabel('Tank Level Response');  
legend('Tank Level Response');  

% Function to compute closed-loop transfer function for given kp and kd  
function T = closed_loop_transfer_function(G, kp, kd)  
    s = tf('s');  % Define Laplace variable  
    C = kp + kd * s;  % PD controller  
    T = feedback(C * G, 1);  % Closed-loop transfer function  
end