% Given system parameters
K = 2; % Gain
num_motor = [5]; % Numerator of Motor and Controller
den_motor = [1, 2, 0]; % Denominator of Motor and Controller
num_vehicle = [1]; % Numerator of Vehicle
den_vehicle = [1, 3, 0]; % Denominator of Vehicle

% Define the original plant transfer function
G_motor = tf(num_motor, den_motor);
G_vehicle = tf(num_vehicle, den_vehicle);
G_original = K * G_motor * G_vehicle;

% Lag compensator parameters
p = 0.1; % Pole of the compensator
z = 0.0033; % Zero of the compensator
num_comp = [1, z];
den_comp = [1, p];
G_comp = tf(num_comp, den_comp);

% New open-loop transfer function
G_OL_new = G_comp * G_original;

% Closed-loop transfer function
G_CL_new = feedback(G_OL_new, 1);

% Bode plot for the new open-loop system
figure;
bode(G_OL_new);
grid on;
title('Bode Plot of New Open-Loop Transfer Function');

% Step response of the compensated closed-loop system
figure;
step(G_CL_new);
grid on;
title('Step Response of Compensated System');
info = stepinfo(G_CL_new);

% Print results
fprintf('Settling Time: %.2f seconds\n', info.SettlingTime);
fprintf('Overshoot: %.2f%%\n', info.Overshoot);

% Steady-state error improvement
Kv_new = dcgain(G_OL_new);
fprintf('Steady-State Velocity Constant (Kv): %.2f\n', Kv_new);
